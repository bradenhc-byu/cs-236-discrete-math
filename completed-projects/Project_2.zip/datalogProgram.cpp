#include "datalogProgram.h"

void datalogProgram::toString(){
	cout << "Success!" << endl;
	cout << "Schemes(" << schemes.size() << "):" << endl;
	for(int x = 0; x < schemes.size();x++){
		cout << "  " << schemes[x].toString() << endl;
	}
	cout << "Facts(" << facts.size() << "):" << endl;
	for(int x = 0; x < facts.size(); x++){
		cout << "  " << facts[x].toString() << "." << endl;
	}
	cout << "Rules(" << rules.size() << "):" << endl;
	for(int x = 0; x < rules.size(); x++){
		cout << "  " << rules[x].toString() << "." << endl;
	}
	cout << "Queries(" << queries.size() << "):" << endl;
	for(int x = 0; x < queries.size(); x++){
		cout << "  " << queries[x].toString() << "?" << endl;
	}
	cout << "Domain(" << domain.size() << "):" << endl;
	set<string>::iterator it = domain.begin();
	for(int x = 0; x < domain.size(); x++){
		cout << "  " << *it << endl;
		++it;
	}
}

void datalogProgram::addscheme(Predicate p){
	schemes.push_back(p);
}

void datalogProgram::addfact(Predicate p){
	facts.push_back(p);
}

void datalogProgram::addrule(Rule r){
	rules.push_back(r);
}

void datalogProgram::addquery(Predicate p){
	queries.push_back(p);
}

void datalogProgram::adddomain(string s){
	domain.insert(s);
}
