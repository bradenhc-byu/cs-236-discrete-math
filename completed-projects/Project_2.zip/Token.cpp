#include "Token.h"
using namespace std;

void Token::setType(string str){
	type = str;
}

void Token::setValue(string str){
	value = str;
}

void Token::setLine(int i){
	line = i;
}

string Token::getType(){
	return type;
}

string Token::getValue(){
	return value;
}

int Token::getLine(){
	return line;
}

void Token::printToken(){
	cout << "(" << type << ",\"" << value << "\"," << line << ")" << endl;
}