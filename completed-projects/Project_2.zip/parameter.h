#pragma once

#include <string>
#include <sstream>
using namespace std;

class Parameter{
public:
	//variables
	string param;

	//functions
	void setParam(string);			//set the parameter
	string toString();		//output the parameter
	string getParam();				//get the parameter
};
