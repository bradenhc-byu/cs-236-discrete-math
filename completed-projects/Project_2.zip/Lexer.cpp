#include "Lexer.h"

void Lexer::scan(string filename){
	line = 1;
	totaltokens = 0;
	myfile.open(filename.c_str());
	c = myfile.get();
	while(myfile.is_open()){
		if(isspace(c)){
			if(c == '\n')
				line++;
			c = myfile.get();
		}else{
		switch(c){
			case ',':																//check for COMMA
				pushCOMMA();
				c = myfile.get();
				break;
			case '.':																//check for PERIOD
				pushPERIOD();
				c = myfile.get();
				break;
			case '?':																//check for Q_MARK
				pushQ_MARK();
				c = myfile.get();
				break;
			case '(':																//check for LEFT_PAREN
				pushLEFT_PAREN();
				c = myfile.get();
				break;
			case ')':																//check for RIGHT_PAREN
				pushRIGHT_PAREN();
				c = myfile.get();
				break;
			case ':':																//check for COLON or COLON_DASH
				checkCOLONorCOLON_DASH();
				c = myfile.get();
				break;
			case '*':																//check for MULTIPLY
				pushMULTIPLY();
				c = myfile.get();
				break;
			case '+':																//check for ADD
				pushADD();
				c = myfile.get();
				break;
			case '#':																//check for COMMENT
				checkCOMMENTorBLOCK_COMMENT();
				break;
			case '\'':																//check for STRING
				getString();
				break;
			case EOF:																//check for end of file
				pushEOF();
				myfile.close();
				break;
			default:																//get ID or UNDEFINED token
				if(isalpha(c)){
					checkId(getId());
				}else{
					string s;
					s += c;
					pushUNDEFINED(s,line);
					c = myfile.get();
				}
		}
		}
	}
}

//check token functions----------------------------------------------------------------------------------------------

void Lexer::checkCOLONorCOLON_DASH(){
	if(myfile.peek() == '-'){
		pushCOLON_DASH();
		c = myfile.get();
	}else{
		pushCOLON();
	}
}

void Lexer::checkCOMMENTorBLOCK_COMMENT(){
	int linestart = line;
	if(myfile.peek() == '|'){
		c = myfile.get();
		c = myfile.get();
		string str = "#|";
		while(c + myfile.peek() != ('|' + '#')){
			if(isNewline(c))
				line++;
			if(c == EOF){
				pushUNDEFINED(str,linestart);
				return;
			}
			str += c;
			c = myfile.get();
		}
		str += "|#";
		c = myfile.get();
		//pushCOMMENT(str,linestart);
	}else{
		string str;
		while(!isNewline(c) && c != EOF){
			str += c;
			c = myfile.get();
		}
		line++;
		//pushCOMMENT(str,linestart);
	}
	c = myfile.get();
}

string Lexer::getId(){
	string str;
	while(isalnum(c)){
		str += c;
		c = myfile.get();
	}
	return str;
}

void Lexer::getString(){
	int linestart = line;
	string str = "\'";
	bool end = false;
	c = myfile.get();
	while(!end){
		if(c == '\'' && myfile.peek() == '\''){
			str += c;
			c = myfile.get();
			str += c;
			c = myfile.get();
		}else if(c == '\''){
			end = true;
		}else if(c == EOF){
			myfile.unget();
			end = true;
			pushUNDEFINED(str,linestart);
			return;
		}else{
			if(isNewline(c))
				line++;
			str += c;
			c = myfile.get();
		}
	}
	str += "\'";
	pushSTRING(str,linestart);
	c = myfile.get();
}

void Lexer::checkId(string str){
	if(str == "Schemes")
		pushSCHEMES();
	else if(str == "Facts")
		pushFACTS();
	else if(str == "Rules")
		pushRULES();
	else if(str == "Queries")
		pushQUERIES();
	else
		pushID(str);
}

bool Lexer::isNewline(char c){
	if(c == '\n')
		return true;
	else
		return false;
}




//push token to vector functions----------------------------------------------------------------------------------------------

void Lexer::pushCOMMA(){
	Token t;
	t.setType("COMMA");
	t.setValue(",");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushPERIOD(){
	Token t;
	t.setType("PERIOD");
	t.setValue(".");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushQ_MARK(){
	Token t;
	t.setType("Q_MARK");
	t.setValue("?");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushLEFT_PAREN(){
	Token t;
	t.setType("LEFT_PAREN");
	t.setValue("(");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushRIGHT_PAREN(){
	Token t;
	t.setType("RIGHT_PAREN");
	t.setValue(")");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushCOLON(){
	Token t;
	t.setType("COLON");
	t.setValue(":");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushCOLON_DASH(){
	Token t;
	t.setType("COLON_DASH");
	t.setValue(":-");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushMULTIPLY(){
	Token t;
	t.setType("MULTIPLY");
	t.setValue("*");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushADD(){
	Token t;
	t.setType("ADD");
	t.setValue("+");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushSCHEMES(){
	Token t;
	t.setType("SCHEMES");
	t.setValue("Schemes");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushFACTS(){
	Token t;
	t.setType("FACTS");
	t.setValue("Facts");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushRULES(){
	Token t;
	t.setType("RULES");
	t.setValue("Rules");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushQUERIES(){
	Token t;
	t.setType("QUERIES");
	t.setValue("Queries");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushID(string id){
	Token t;
	string valuestring = id;
	t.setType("ID");
	t.setValue(valuestring);
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushSTRING(string str, int linestart){
	Token t;
	string valuestring = str;
	t.setType("STRING");
	t.setValue(valuestring);
	t.setLine(linestart);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushCOMMENT(string com, int linestart){
	Token t;
	string valuestring = com;
	t.setType("COMMENT");
	t.setValue(valuestring);
	t.setLine(linestart);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushUNDEFINED(string und, int linestart){
	Token t;
	string valuestring = und;
	t.setType("UNDEFINED");
	t.setValue(valuestring);
	t.setLine(linestart);
	v.push_back(t);
	totaltokens++;
}

void Lexer::pushEOF(){
	Token t;
	t.setType("EOF");
	t.setValue("");
	t.setLine(line);
	v.push_back(t);
	totaltokens++;
}

//print function------------------------------------------------------------------------------------

void Lexer::printTokens(){
	for(size_t x = 0; x < v.size();x++){
		cout << "(" << v[x].getType() << "," << v[x].getValue() << "," << v[x].getLine() << ")" << endl;
	}
	cout << "Total Tokens = " << totaltokens << endl;
}

//get vector function-------------------------------------------------------------------------------
vector<Token> Lexer::getVector(){
	return v;
}
