#include "Parser.h"
#include <cstdlib>
using namespace std;

int main(int argc, char *argv[]){
	string filename = argv[1];
	Lexer l;
	Parser p;
	l.scan(filename);
	p.parse(l.getVector());
	return 0;
}
