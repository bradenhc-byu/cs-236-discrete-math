#pragma once

#include "predicate.h"
#include <vector>
#include <sstream>
using namespace std;

class Rule{
public:
	//variables
	Predicate headpred;			//head predicate to rule
	vector<Predicate> pred;		//other predicates inside the rule

	//functions
	void addPred(Predicate);		//add a predicate to the rule
	void setHeadPred(Predicate);	//set the head predicate
	string toString();				//output the rule
};
