#pragma once

#include "relation.h"
#include "predicate.h"
#include <map>
#include <string>

using namespace std;

class Database{
public:
	//variables
	map<string,relation> m;			//map representing the database
	int size;

	//get, set, add methods
	void addRelation(relation);		//adds a relation to the database
	void addValue(string,vector<string>& values);	//adds a value to a relation in the database
	map<string,relation> getDatabase();		//returns the database
	int getSize();
	relation getRelation(string);
	void setSize();

	//check methods
	bool has(string);				//returns true if the given relation is in the database
};