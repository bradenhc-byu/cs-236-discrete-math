#pragma once

#include "Parser.h"
#include "relation.h"
#include "predicate.h"
#include "database.h"
#include "rule.h"
#include "datalogProgram.h"
#include <string>
#include <iostream>
#include <vector>
#include <set>
#include <utility>

using namespace std;

class DatabaseManager{
public:
	//variables
	Database database;
	Predicate query;							//query to be analyzed
	vector<pair<string,vector<int>>> ids;		//ids in the query and their position
	datalogProgram dataProg;
	int rulePasses;

	
	//methods
	void manage(Database,datalogProgram);
	relation getRelation(string,Predicate,set<string>,bool);
	void evaluateRules();
	relation join(relation& r1,relation& r2);
	relation joinMatch(relation& r1,relation& r2,vector<pair<int,int>> duplicates);
	relation cross(relation& r1,relation& r2);
	void projectAndAdd(relation& r);

	void addID(string,int);
	void getID(string,int);


};