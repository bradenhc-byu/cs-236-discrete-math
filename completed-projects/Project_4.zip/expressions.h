#pragma once

#include <string>
using namespace std;

class Expression{
public:
	string express;		//new expression

	void add(string);	//build on to the expression
	string get();		//get the expression
	void clear();		//clear the expression string
};