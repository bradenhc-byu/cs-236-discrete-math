#include "DatabaseManager.h"

//**********Evaluates the Queries for a valid Parsed Datalog Program*************************************

void DatabaseManager::manage(Database db, datalogProgram dataP){
	rulePasses = 0;
	database = db;
	dataProg = dataP;
	database.setSize();
	set<string> domain = dataP.getDomain();
	evaluateRules();
	cout << "Schemes populated after " << rulePasses << " passes through the Rules." << endl;
	for(size_t qpos = 0; qpos < dataProg.getQueries().size(); qpos++){
		ids.clear();								//reset the vector containing ids for this query
		query = dataProg.getQueries()[qpos];						//get the query
		cout << query.toString() << "? ";
		relation result = getRelation(query.getName(),query,domain,true);
		if(result.getValues().size() != 0){				//check to see if the query is true or false
			cout << "Yes(" << result.getValues().size() << ")" << endl;
			result.toString();
		}else{																//else ouptut no
			cout << "No" << endl;
		}
	}
}

//**********Evaluates the Rules that were parsed from a Valid Datalog Program*******************************

void DatabaseManager::evaluateRules(){
	vector<Rule> rules = dataProg.getRules();						//get the rules to evaluate
	rulePasses = 0;													//initiate variables
	bool change = true;
	int size = 0;
	while(change){													//Fixed-Point Algorithm: While there is a change
		rulePasses++;								
		for(int x = 0; x < rules.size(); x++){						//evaluate each rule individually
			Rule thisRule = rules[x];
			Predicate headPred = thisRule.getHeadPred();
			vector<Predicate> preds = thisRule.getPredicates();
			relation r = getRelation(preds[0].getName(),preds[0],dataProg.getDomain(),false);
			for(int y = 1; y < preds.size(); y++){
				relation nextR = getRelation(preds[y].getName(),preds[y],dataProg.getDomain(),false);
				r = join(r,nextR);									//if there is more than one predicate, join
			}
			r.setName(headPred.getName());
			ids.clear();
			for(int x = 0; x < headPred.getParams().size(); x++){	//get the parameters to project on from the rule
				getID(headPred.getStringParams()[x],x);
			}
			projectAndAdd(r);										//project on the relation
			ids.clear();
 		}
		if(database.getSize() == size)								//check to see if database size changed
			change = false;
		else
			size = database.getSize();
	}
}

//**********Projects on a Relation and adds the tuples to the database (used only when evaluating Rules)********************

void DatabaseManager::projectAndAdd(relation& jr){
	string name = jr.getName();
	relation r;													//create new relation with new schema
	r.setName(name);
	vector<string> newSchema;
	for(int x = 0; x < ids.size(); x++){
		newSchema.push_back(ids[x].first);
	}
	r.setSchema(newSchema);
	set<vector<string>>::iterator it;
	set<vector<string>> vals = jr.getValues();
	vector<string> schema = jr.getSchema();
	for(it = vals.begin(); it != vals.end(); ++it){				//for each tuple
		vector<string> temp = *it;
		vector<string> tempVal;
		for(int x = 0; x < ids.size(); x++){
			for(int y = 0; y < schema.size(); y++){
				if(ids[x].first == schema[y]){					//if the values in the schema match
					tempVal.push_back(temp[y]);						//add it to the new tuple
					break;
				}
			}
		}
		database.addValue(name,tempVal);						//add the new tuple to the database;
	}
}

//**********Takes two relations and does a natural join, returning the result relation*****************************

relation DatabaseManager::join(relation& r1, relation& r2){		//joins two relations
	relation jr;
	jr.setJoinSchema(r1,r2);									//create new relation
	bool matchFound = false;
	vector<pair<int,int>> duplicates;
	for(int x = 0; x < r1.getSchema().size(); x++){				//check schema of both relations
		for(int y = 0; y < r2.getSchema().size(); y++){
			if(r1.getSchema()[x] == r2.getSchema()[y]){			//when a match is found in the schema
				pair<int,int> match(x,y);
				duplicates.push_back(match);
				matchFound = true;
			}
		}
	}
	if(matchFound)
		return jr = joinMatch(r1,r2,duplicates);
	else
		return cross(r1,r2);					//if there were no matches, compute the cross product
}

//**********Executes the natural join when matches are found within the schema of two relations**********************

relation DatabaseManager::joinMatch(relation& r1, relation& r2, vector<pair<int,int>> duplicates){
	relation jr;														//create a new relation
	jr.setJoinSchema(r1,r2);
	set<vector<string>>::iterator r1it;
	set<vector<string>>::iterator r2it;
	set<vector<string>> r1val = r1.getValues();
	set<vector<string>> r2val = r2.getValues();
	for(r1it = r1val.begin(); r1it != r1val.end(); ++r1it){				//for each tuple in the relations
		vector<string> r1vec = *r1it;
		for(r2it = r2val.begin(); r2it != r2val.end(); ++r2it){
			vector<string> r2vec = *r2it;
			bool canAdd = true;
			for(int x = 0; x < duplicates.size(); x++){
				if(r1vec[duplicates[x].first] != r2vec[duplicates[x].second])
					canAdd = false;										//add the new tuple to the relation
			}
			if(canAdd){
				vector<string> joinedValues;
				for(int i = 0; i < r1vec.size(); i++){
					joinedValues.push_back(r1vec[i]);
				}
				for(int i = 0; i < r2.getSchema().size(); i++){
					if(!r1.schemaHas(r2.getSchema()[i]))
						joinedValues.push_back(r2vec[i]);
				}
				jr.addValue(joinedValues);
			}
		}
	}
	return jr;
}

//**********Returns the cross product of two relations**********************************************************

relation DatabaseManager::cross(relation& r1, relation& r2){
	relation jr;
	jr.setJoinSchema(r1,r2);										//create new relation
	set<vector<string>>::iterator r1it;
	set<vector<string>>::iterator r2it;
	set<vector<string>> r1val = r1.getValues();
	set<vector<string>> r2val = r2.getValues();
	for(r1it = r1val.begin(); r1it != r1val.end(); ++r1it){			//for every tuple in each relation
		vector<string> temp1;
		temp1 = *r1it;
		for(r2it = r2val.begin(); r2it != r2val.end(); ++r2it){
			vector<string> temp2;
			temp2 = *r2it;
			for(int x = 0; x < temp2.size(); x++){							//find cross product of the tuples
				temp1.push_back(temp2[x]);
			}
			jr.addValue(temp1);										//add the values to the new relation
			temp1 = *r1it;
		}
	}
	return jr;
}

//**********Returns the result relation when answering a query or creates a relation when evaluating rules************

relation DatabaseManager::getRelation(string name, Predicate q, set<string> domain,bool isQuery){
	relation result;											//copy relation in database
	result.setName(query.getName());
	result.setSchema(database.getDatabase()[name].getSchema());
	result.setValues(database.getDatabase()[name].getValues());
	ids.clear();
	vector<Parameter> params = q.getParams();					//get parameters in query
	for(size_t x = 0; x < params.size(); x++){					//get all the ids or select on constants
		string value = params[x].getParam();
		if(domain.find(value) == domain.end()){				//if it is not a constant not in the domain
			if(value.at(0) == '\''){							//if it is a constant
				result.clear();										//return empty relation
				return result;
			}
			getID(value,x);
		}else{												//if it is not an ID
			result = result.select(x,value);					//select on the constant
		}															
	}
	result = result.selectDuplicate(ids);
	for(int x = 0; x < ids.size(); x++)
			result = result.rename(ids[x].second,ids[x].first);
	if(isQuery){
		result = result.project(ids);								//project on the relation with IDs
	}
	return result;
}

//**********Adds an ID found in the parameters of a predicate to the ID vector***************************************

void DatabaseManager::addID(string s, int i){
	pair<string,vector<int>> id;
	id.first = s;
	id.second.push_back(i);
	ids.push_back(id);
}

//**********Gets the IDs from the parameters of a predicate and adds them to the vector of IDs************************

void DatabaseManager::getID(string value, int x){
	if(ids.size() == 0)									//if it is an ID
		addID(value,x);
	else{
		bool canAdd = true;
		for(int y = 0; y < ids.size(); y++){
			if(ids[y].first == value){					//if the ID is a duplicate
				ids[y].second.push_back(x);					//add its position
				canAdd = false;
			}			
		}
		if(canAdd)										//if the ID is unique
			addID(value,x);									//add new ID
	}
}