#include "predicate.h"

void Predicate::setName(string n){
	name = n;
}

void Predicate::addParam(string s){
	Parameter p;
	p.setParam(s);
	param.push_back(p);
}

string Predicate::getName(){
	return name;
}

vector<Parameter> Predicate::getParams(){
	return param;
}

string Predicate::toString(){
	string output;
	output += name;
	output += "(";
	for(int x = 0; x < param.size(); x++){
		output += param[x].toString();
		if(x+1 < param.size())
			output += ",";
	}
	output += ")";
	return output;
}

vector<string> Predicate::getStringParams(){
	vector<string> s;
	for(int x = 0; x < param.size(); x++){
		s.push_back(param[x].getParam());
	}
	return s;
}