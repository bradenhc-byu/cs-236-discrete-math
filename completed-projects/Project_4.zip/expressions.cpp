#include "expressions.h"

void Expression::add(string s){
	express += s;
}

string Expression::get(){
	return express;
}

void Expression::clear(){
	express = "";
}