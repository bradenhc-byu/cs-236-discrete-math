#pragma once

#include "rule.h"
#include "predicate.h"
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <set>

using namespace std;

class datalogProgram{
public:
	vector<Predicate> schemes;		//contains all the strings found in SCHEMES:
	vector<Predicate> facts;		//contains all the strings found in FACTS:
	vector<Rule> rules;				//contains all the strings found in RULES:
	vector<Predicate> queries;		//contains all the strings found in QUERIES:
	set<string> domain;				//contains all the domain values found in FACTS:

	//get, set functions
	vector<Predicate> getQueries();
	set<string> getDomain();
	vector<Rule> getRules();

	//functions
	void toString();				//output the datalogProgram after parse is finished
	void addscheme(Predicate);		//add a predicate to the scheme list
	void addfact(Predicate);		//add a predicate to the fact list
	void addrule(Rule);				//add a rule to the rule list
	void addquery(Predicate);		//add a predicate to the query list
	void adddomain(string);			//add a domain to the domain set


};
