#include "database.h"

void Database::addRelation(relation r){					//adds a relation to the database
	m.insert(pair<string,relation>(r.getName(),r));
}

bool Database::has(string s){							//determines if this database has a relation with name s
	if(m.find(s) != m.end())							//returns true if it exists
		return true;
	else
		return false;
}

map<string,relation> Database::getDatabase(){			//returns the database
	return m;
}

void Database::addValue(string name, vector<string> &values){		//adds a vector of values to a relation in the database
	bool inserted = m[name].addValue(values);
	if(inserted){
		size++;
	}
	
}

int Database::getSize(){
	return size;
}

relation Database::getRelation(string name){
	return m[name];
}

void Database::setSize(){
	size = 0;
}