#pragma once

#include "parameter.h"
#include <vector>
#include <string>
#include <sstream>
using namespace std;

class Predicate{
public:
	//variables
	string name;				//name of predicate
	vector<Parameter> param;	//parameters in the predicate

	//functions
	void setName(string);				//set name of predicate
	void addParam(string);				//add a parameter to the vector
	string getName();					//get the name of the predicate
	vector<Parameter> getParams();		//get the vector of parameters for this predicate
	vector<string> getStringParams();
	string toString();					//output predicate
};
