#include "rule.h"

void Rule::setHeadPred(Predicate p){
	headpred = p;
}

void Rule::addPred(Predicate p){
	pred.push_back(p);
}

string Rule::toString(){
	string output;
	output += headpred.toString();
	output += " :- ";
	for(int x = 0; x < pred.size(); x++){
		output += pred[x].toString();
		if(x+1 < pred.size())
			output += ",";
	}
	return output;
}

vector<Predicate> Rule::getPredicates(){
	return pred;
}

Predicate Rule::getHeadPred(){
	return headpred;
}
