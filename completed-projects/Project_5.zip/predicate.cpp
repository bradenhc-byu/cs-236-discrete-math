#include "predicate.h"

//**********Sets the name of the predicate to the value n**************

void Predicate::setName(string n){
	name = n;
}

//**********Adds a parameter to the predicate**************************

void Predicate::addParam(string s){
	Parameter p;
	p.setParam(s);
	param.push_back(p);
}

//**********Returns the name of the predicate***************************

string Predicate::getName(){
	return name;
}

//**********Returns the vector of parameters in the predicate***********

vector<Parameter> Predicate::getParams(){
	return param;
}

//**********Converts the predicate to a string to be outputed************

string Predicate::toString(){
	string output;
	output += name;
	output += "(";
	for(int x = 0; x < param.size(); x++){
		output += param[x].toString();
		if(x+1 < param.size())
			output += ",";
	}
	output += ")";
	return output;
}

//**********returns a vector of strings containing the value of the parameters in the predicate

vector<string> Predicate::getStringParams(){
	vector<string> s;
	for(int x = 0; x < param.size(); x++){
		s.push_back(param[x].getParam());
	}
	return s;
}