#pragma once

#include "parameter.h"
#include <vector>
#include <string>
#include <sstream>
using namespace std;

class Predicate{
public:
//**********Variables*******************************************************************************
	string name;				//name of predicate
	vector<Parameter> param;	//parameters in the predicate

//**********Get and Set Functions*******************************************************************
	void setName(string);				//set name of predicate
	string getName();					//get the name of the predicate
	vector<Parameter> getParams();		//get the vector of parameters for this predicate
	vector<string> getStringParams();	//returns the parameters in a vector of strings

//**********Modify Functions************************************************************************
	void addParam(string);				//add a parameter to the vector
	string toString();					//output predicate
};
