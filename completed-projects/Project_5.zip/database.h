#pragma once

#include "relation.h"
#include "predicate.h"
#include <map>
#include <string>

using namespace std;

class Database{
public:
//**********Variables*********************************************************************************
	map<string,relation> m;			//map representing the database
	int size;						//increments as elements are added to the database

//**********Get and Set Methods***********************************************************************
	//*****Returns a relation by name
	relation getRelation(string);

	//*****Returns the size of the database
	int getSize();

	//*****Returns the database
	map<string,relation> getDatabase();		

	//*****Sets the size of the database to 0
	void setSize();

//**********Modify and Check Methods******************************************************************
	//*****Adds a relation to the database
	void addRelation(relation);

	//*****Adds a tuple to a relation in the database
	void addValue(string,vector<string>& values);

	//*****Returns true if the relation with the given name is in the database
	bool has(string);
};