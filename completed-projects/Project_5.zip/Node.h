#pragma once

#include <string>
#include <vector>
#include "rule.h"

using namespace std;

class Node{
public:
//*****Variables********************************************************
	int number;			//name of the node (rule number)
	vector<int> children;	//nodes connected to this node
	bool visited;			//true if the node has been visited in a DFS

//*****Constructor, get and set functions*******************************
	//*****Default Constructor
	Node();
	
	//*****Constructor
	Node(int,vector<int>);

	//*****Destructor
	~Node();

	//*****Sets the name
	void setNumber(int);

	//*****Adds a child to the node vector
	void addChild(int);

	//*****Sets the value of visited to true
	void wasVisited();

	//*****Resets the value of visited to false
	void setVisit(bool);

	//*****Returns the name of the node (rule number)
	int getNumber();

	//*****Returns the children of the node
	vector<int> getChildren();

	//*****Returns the value of visited
	bool getVisited();

};