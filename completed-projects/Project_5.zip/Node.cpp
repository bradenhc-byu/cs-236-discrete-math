#include "Node.h"

//*****Default Constructor
Node::Node(){
	number = 0;
	vector<int> c;
	children = c;
	visited = false;
}

//*****Constructs a new Node with the rule number*********
Node::Node(int n, vector<int> c){
	number = n;
	children = c;
	visited = false;
}

//*****Destructor****************************************
Node::~Node(){}

//*****Sets the name of the Node to n*********************
void Node::setNumber(int n){
	number = n;
}

//*****Adds a child to the Node's children vector*********
void Node::addChild(int n){
	children.push_back(n);
}

//*****Ses the value of visited to true*******************
void Node::wasVisited(){
	visited = true;
}

//*****Resets the value of visited to false****************
void Node::setVisit(bool b){
	visited = b;
}

//*****Returns the name of the Node************************
int Node::getNumber(){
	return number;
}

//*****Returns the children of the Node*********************
vector<int> Node::getChildren(){
	return children;
}

//*****Returns the value of visited*************************
bool Node::getVisited(){
	return visited;
}