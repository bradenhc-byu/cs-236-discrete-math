#pragma once

#include "predicate.h"
#include <vector>
#include <sstream>
using namespace std;

class Rule{
public:
//***********Variables**************************************************
	Predicate headpred;			//head predicate to rule
	vector<Predicate> pred;		//other predicates inside the rule
	int num;					//number of the rule in the program

//***********Functions**************************************************
	void addPred(Predicate);			//add a predicate to the rule
	void setHeadPred(Predicate);		//set the head predicate
	string toString();					//output the rule
	vector<Predicate> getPredicates();	//returns the predicates
	Predicate getHeadPred();			//returns the head predicate
	void setNum(int);					//sets the number of the rule
	int getNum();						//returns the number of the rule
};
