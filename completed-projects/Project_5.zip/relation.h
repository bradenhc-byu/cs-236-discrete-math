#pragma once

#include <string>
#include <set>
#include <vector>
#include <utility>
#include <iostream>

using namespace std;

class relation{
public:
//**********Variables*****************************************************************************************
	string name;						//name of the relation
	vector<string> schema;				//schema of the relation (attributes)
	set<vector<string>> values;			//tuples in the relation (values)
	
//**********Get and Set Methods*******************************************************************************
	//*****Returns the name of the relation
	string getName();

	//*****Returns the Schema of the relation
	vector<string> getSchema();	

	//*****Returns the set of tuples (values) in the relation
	set<vector<string>> getValues();

	//*****Sets the name to the given string value
	void setName(string);

	//*****Sets a particular Attribute in the schema to a given value (for renaming)
	void setAttribute(int,string);

	//*****Sets the schema to the given vector of strings
	void setSchema(vector<string>);	

	//*****Sets the set of tuples to the given set of values (tuples: vectors of strings)
	void setValues(set<vector<string>>);

	//*****Sets the schema to the result relation schema for a natural join of two relations
	void setJoinSchema(relation,relation);

//**********Modify and Check Functions***************************************************************************
	//*****Adds a schema attribute to the relation
	void addSchema(string);

	//*****Adds a tuple to the values set of the relation
	bool addValue(vector<string>& v);				

	//*****Clears the values for name, schema, and values
	void clear();								
								
	//*****Checks to see if the schema has a given attribute
	bool schemaHas(string);

	//*****Checks to see if a given tuple is valid
	bool isValidTuple(vector<pair<string,vector<int>>>,vector<string>,int);


//**********Relational Algebra*******************************************************************************************
	//*****Selects on the relation given a schema position and a value and returns the new relation
	relation select(int,string);

	//*****Selects on a relation when multiple schemas are the same (therefore must have the same value); returns new relation
	relation selectDuplicate(vector<pair<string,vector<int>>>);

	//*****Projects on the relation given the IDs and returns the new relation
	relation project(vector<pair<string,vector<int>>>);

	//*****Renames Schema within the relation, returning the new relation
	relation rename(vector<int>,string);




	//*****Outputs the relation as a string in the console
	void toString();
	
};