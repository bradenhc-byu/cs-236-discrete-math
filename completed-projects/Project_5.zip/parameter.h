#pragma once

#include <string>
#include <sstream>
using namespace std;

class Parameter{
public:
//**********Variables*************************************************************
	string param;			//value of the parameter

//**********Functions************************************************************
	void setParam(string);			//set the parameter
	string toString();				//output the parameter
	string getParam();				//get the parameter
};
