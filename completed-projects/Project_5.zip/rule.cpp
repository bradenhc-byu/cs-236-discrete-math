#include "rule.h"

//**********Sets the value of the head predicate to the predicate p*************************

void Rule::setHeadPred(Predicate p){
	headpred = p;
}

//**********Adds a predicate  p to the rule**************************************************

void Rule::addPred(Predicate p){
	pred.push_back(p);
}

//**********Converts the rule to a string in the format headPred:-Pred(param),Pred(param)*****

string Rule::toString(){
	string output;
	output += headpred.toString();
	output += " :- ";
	for(int x = 0; x < pred.size(); x++){
		output += pred[x].toString();
		if(x+1 < pred.size())
			output += ",";
	}
	return output;
}

//**********Returns the vector containing all the predicates in the rule

vector<Predicate> Rule::getPredicates(){
	return pred;
}

//**********Returns the value of the head predicate

Predicate Rule::getHeadPred(){
	return headpred;
}

//**********Sets the number of the rule to the given value*************

void Rule::setNum(int val){
	num = val;
}

//**********Returns the number value of the rule**********************

int Rule::getNum(){
	return num;
}
