#include "database.h"

//**********Adds a relation to the database**********************************************

void Database::addRelation(relation r){	
	m.insert(pair<string,relation>(r.getName(),r));
}

//**********Checks to see if the database has the given relation name s******************

bool Database::has(string s){
	if(m.find(s) != m.end())		//returns true if it exists
		return true;
	else
		return false;
}

//**********Returns the database**********************************************************

map<string,relation> Database::getDatabase(){
	return m;
}

//**********Adds a vector of values to a relation in the database*************************

void Database::addValue(string name, vector<string> &values){
	bool inserted = m[name].addValue(values);
	if(inserted){
		size++;
	}
}

//*********Returns the size of the database (not accurate, simply used to determine if****
//*********a values were added to a relation in the database)*****************************

int Database::getSize(){
	return size;
}

//**********returns a relation within the database****************************************

relation Database::getRelation(string name){
	return m[name];
}

//*********Reset the size counter of the database to 0************************************

void Database::setSize(){
	size = 0;
}