#pragma once

#include "Lexer.h"
#include "datalogProgram.h"
#include "predicate.h"
#include "rule.h"
#include "expressions.h"
#include "database.h"
#include "relation.h"
#include <string>
#include <vector>


using namespace std;

class Parser{
public:
//**********Variables**********************************************************************************
	int vpos;					//position in the vector
	int leftparen;				//counts number of left parentheses in expression
	int rightparen;				//counts number of right parentheses in expression
	datalogProgram p;			//start point for grammar
	Database d;					//database to add relations and facts to during parse
	vector<Parameter> param;	//vector of parameters for new predicate
	Predicate newPred;			//used to create new predicates
	Rule newRule;				//used to create new rules
	Expression newExp;			//used to create new expressions
	int ruleNum;				//number of the rule - increments with each rule

//**********Get and Set Functions**********************************************************************
	//*****Returns the vector of queries
	vector<Predicate> getQueries();

	//*****Returns the set containing the domain
	set<string> getDomain();

	//*****Returns the datalog program created after the parse
	datalogProgram getDatalogProgram();

//**********Main Execution Functions*******************************************************************
	//*****Takes the vector of tokens from the Lexer and parses it; returns "Success!" or "Failure!"
	Database parse(vector<Token>);

	//*****Creates a new expression to add as a parameter
	void createexpression();

	//*****Checks to see if the tokens are in the Grammar
	void match(string type);

	//*****Productions in Datalog grammar
	void scheme();
	void schemelist();
	void idlist();
	void factlist();
	void fact();
	void stringlist();
	void rulelist();
	void rule();
	void headpredicate();
	void predicate();
	void parameter();
	void expression();
	void operate();
	void paramlist();
	void predicatelist();
	void toquery();
	void toquerylist();

private:
	vector<Token> vt;			//vector of tokens from Lexer
};