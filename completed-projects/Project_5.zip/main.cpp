#include "Parser.h"
#include "DatabaseManager.h"
#include <iostream>
#include <cstdlib>
using namespace std;

int main(int argc, char *argv[]){
	string filename = argv[1];
	Lexer l;
	Parser p;
	Database d;
	DatabaseManager dm;
	l.scan(filename);
	d = p.parse(l.getVector());
	dm.manage(d,p.getDatalogProgram());
	system("pause");
	return 0;
}
