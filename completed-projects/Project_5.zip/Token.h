#pragma once

#include <string>
#include <iostream>
using namespace std;

//class to be put into vector of tokens
class Token{
public:
//**********Variables*****************************************************
	string type;		//type of token (STRING, ID, RIGHT_PAREN, etc)
	string value;		//value of the token
	int line;			//line in the datalog program the token is on

//**********Get and Set Functions*****************************************
	//*****Set the type of token
	void setType(string);

	//*****Set the value of the token
	void setValue(string);

	//*****Set the line number the token is on
	void setLine(int);

	//*****Returns the type of token
	string getType();

	//*****Returns the value of the token
	string getValue();

	//*****Returns the line number the token is on
	int getLine();

	//*****Prints the Token to the console
	void printToken();
};