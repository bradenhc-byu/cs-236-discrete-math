#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "Token.h"
using namespace std;

class Lexer{
public:
//***********Variables**********************************************************************
	char c;						//character being evaluated
	int line;					//line number the lexical analyzer is on
	int totaltokens;			//number of total tokens the Lexer has scanned
	ifstream myfile;			//file being scanned
	vector<Token> v;			//vector containing the tokens

//**********Evaluate Functions***********************************************************
	//*****Get the input file and scan
	void scan(string);

	//*****Get the output vector after the scan
	vector<Token> getVector();

	//*****Computes and Returns the ID
	string getId();

	//*****Computes and returns the STRING
	void getString();

	//*****Checks to see if the character is part of an ID
	void checkId(string);

	//*****Checks to see if the character is part of a COLON or COLON_DASH
	void checkCOLONorCOLON_DASH();

	//*****Checks to see if the character is part of a COMMENT or BLOCK_COMMENT
	void checkCOMMENTorBLOCK_COMMENT();

	//*****Checks to see if the character is '\n'
	bool isNewline(char);

	//*****Create token and push to vector functions
	void pushCOMMA();
	void pushPERIOD();
	void pushQ_MARK();
	void pushLEFT_PAREN();
	void pushRIGHT_PAREN();
	void pushCOLON();
	void pushCOLON_DASH();
	void pushMULTIPLY();
	void pushADD();
	void pushSCHEMES();
	void pushFACTS();
	void pushRULES();
	void pushQUERIES();
	void pushID(string);
	void pushSTRING(string,int);
	void pushCOMMENT(string,int);
	void pushUNDEFINED(string,int);
	void pushEOF();

	//*****Print the vector of tokens
	void printTokens();

};
