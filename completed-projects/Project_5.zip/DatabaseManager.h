#pragma once

#include "Parser.h"
#include "relation.h"
#include "predicate.h"
#include "database.h"
#include "rule.h"
#include "datalogProgram.h"
#include "Node.h"
#include "Tree.h"
#include <string>
#include <iostream>
#include <vector>
#include <set>
#include <utility>

using namespace std;

class DatabaseManager{
public:
//**********Variables**********************************************************
	Database database;							//modifiable database containing facts
	Predicate query;							//query to be analyzed
	vector<pair<string,vector<int>>> ids;		//ids in the query and rules and their position
	datalogProgram dataProg;					//datalog program produced by the parse
	int rulePasses;								//counter for the number of rule passes
	vector<Node> ruleNodes;						//vector of rules converted to Nodes
	vector<Node> reverseRuleNodes;				//vector of rules from the reverse dependence graph
	map<int,vector<int>> depGraph;				//Dependency Graph for the rules
	map<int,vector<int>> revDepGraph;			//Reverse Dependency Graph for the rules
	vector<int> precedence;						//vector containing the rules in precendence order
	vector<Tree> SCCForest;						//vector of strongly connected components
	Tree tree;									//SCC in Pre order traversal numbering

	
//**********Database Functions*************************************************
	//*****Constructor
	DatabaseManager();
	//*****Takes a database filled with facts from the parse and evaluates rules and queries
	void manage(Database,datalogProgram);						

	//*****Converts a predicate rule or query into the resulting relation from the database
	relation getRelation(string,Predicate,set<string>,bool);

	//*****Evaluates the rules in the datalog program obtained from the parse
	void evaluateRules();

	//*****Evaluates a rule once if it is trivial
	void evaluateRuleOnce(vector<Rule>&);

	//*****Evaluates a SCC of rules
	void evaluateSCC(vector<Rule>&);

	//*****Creates the SCC Forest used to optimize Rule evaluation
	void getSCCForest(vector<Rule>&);

	//*****Creates the vector of Nodes associated with rules
	void createForest(vector<Rule>&);

	//*****Gets the children for the node when creating the forest
	vector<int> getChildren(vector<Rule>&,Rule);

	//*****Creates a dependency graph in a map of the rules
	void getDependency();

	//*****Creates a reverse dependency graph
	void getReverseDependency();

	//*****Creates a Forest of Nodes from the reverse dependency graph
	void createReverseForest();

	//*****Performs a DFS on the reverse dependency (using recursion)
	void DFS(int);

	//*****Sets the values of the nodes to true when they are visited
	void visited(int,string);

	//*****Returns the node associated with the reverse dependency graph
	Node getReverseGraphNode(int);

	//*****Returns the Node associated with the given rule number
	Node getNode(int);

	//*****Resets the visited values of the Nodes to false
	void resetNodes();

	//*****Creates the SCC trees and puts them in the forest
	void createSCCForest(vector<Rule>&);

	//*****Performs a DFS search on the dependency list
	void dependencyDFS(vector<Rule>&,int);

	//*****Returns the rule associated with the given rule number
	Rule getRule(vector<Rule>&,int);

	//*****Performs a natural join or a cross product on two relations when evaluating rules
	relation join(relation& r1,relation& r2);

	//*****Joins two relations if matches are found within the schema
	relation joinMatch(relation& r1,relation& r2,vector<pair<int,int>> duplicates);

	//*****Returns the cross product of two relations (when a match is not found in schema)
	relation cross(relation& r1,relation& r2);

	//*****Projects on the result relation of a rule and adds the facts to the database
	void projectAndAdd(relation& r);

	//*****Takes the parameters of a rule or query predicate and stores IDs in a vector
	void getID(string,int);

	//*****Adds an ID to the vector once it is found in the parameters
	void addID(string,int);

	//*****Determines whether a rule is trivial (doesn't depend on itself)
	bool isTrivial(Rule);

	//*****Prints out the dependency graph
	void printDependency();

	//*****Prints out the reverse dependency graph
	void printRevDependency();

	//*****Prints the number of rule passes per rule
	void printRulePasses(int,vector<Rule>&);


};