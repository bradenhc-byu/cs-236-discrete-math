#include "relation.h"

//*********Sets the name of the relation to s*************************************
void relation::setName(string s){
	name = s;
}

//**********Sets an attribute at a given location in the schema (for rename)******

void relation::setAttribute(int x, string s){
	schema[x] = s;
}

//**********Adds an attribute to the schema***************************************
void relation::addSchema(string s){
	schema.push_back(s);
}

//**********Adds a tuple to the relation******************************************
bool relation::addValue(vector<string> &v){
	pair<set<vector<string>>::iterator,bool> inserted = values.insert(v);
	if(inserted.second)
		return true;
	else
		return false;
}

//**********Clears the relation, reseting all values to NULL state****************
void relation::clear(){	
	name = "";
	schema.clear();
	values.clear();
}

//**********Returns the name of the relation**************************************
string relation::getName(){
	return name;
}

//**********Returns the schema of the relation************************************
vector<string> relation::getSchema(){
	return schema;
}

//**********Returns the set of values (tuples) in the relation********************
set<vector<string>> relation::getValues(){
	return values;
}

//**********Sets the schema for the vector(contructor)****************************
void relation::setSchema(vector<string> s){	
	schema = s;
}

//**********Sets the schema if the relation is a join of two relations************
void relation::setJoinSchema(relation r1, relation r2){
	schema = r1.getSchema();
	vector<string> r2schema = r2.getSchema();
	for(int x = 0; x < r2schema.size(); x++){
		if(!schemaHas(r2schema[x]))
			schema.push_back(r2schema[x]);
	}
}

//**********Checks to see if the schema has the given attribute*******************
bool relation::schemaHas(string s){
	for(int x = 0; x < schema.size(); x++){
		if(schema[x] == s)
			return true;
	}
	return false;
}

//**********Constructs the set of tuples in the relation**************************
void relation::setValues(set<vector<string>> v){
	values = v;
}

//**********Performs a selection on the relation, returning a new result relation**
relation relation::select(int x, string val){
	relation r;
	r.setName(name);
	r.setSchema(schema);
	set<vector<string>>::iterator it;
	for(it = values.begin();it != values.end(); ++it){
		vector<string> v = *it;
		if(v[x] == val){
			r.addValue(v);
		}
	}
	return r;
}

//**********Performs a selection on a relation for when duplicate attributes are found***********************************
relation relation::selectDuplicate(vector<pair<string,vector<int>>> ids){
	relation r;	//create new relation and initialize variables
	r.setName(name);
	r.setSchema(schema);
	bool added = false;		//was a value added to the new relation?
	bool duplicate = false;	//was a duplicate id found?
	vector<vector<string>> failedTuples;
	if(ids.size() == schema.size()){
		r.setValues(values);	//return the relation itself if all schema are in the ids vector
		return r;
	}
	for(int x = 0; x < ids.size(); x++){								//for each id to be selected
		if(ids[x].second.size() > 1){										//if it is a duplicate
			bool failed = false;												//select all tuples with matching values
			duplicate = true;
			set<vector<string>>::iterator it;
			for(it = values.begin(); it != values.end(); it++){
				bool canSelect = true;
				vector<string> v = *it;
				for(int z = 0; z < failedTuples.size(); z++){
					if(failedTuples[z] == v)
						failed = true;
				}
				if(!failed){
					for(int y = 0; y < ids[x].second.size(); y++){
						if(y+1 != ids[x].second.size() && v[ids[x].second[y]] != v[ids[x].second[y+1]]){
							failedTuples.push_back(v);
							canSelect = false;
							break;
						}
					}
					if(canSelect && isValidTuple(ids,v,x)){
						r.addValue(v);
						added = true;
					}
				}
			}
		}
	}
	if(!added && !duplicate)
		r.setValues(values);
	return r;

}

//**********Projects on a relation and returns a result relation******************************
relation relation::project(vector<pair<string,vector<int>>> ids){
	relation r;
	r.setName(name);
	vector<string> newSchema;
	for(int x = 0; x < ids.size(); x++){
		newSchema.push_back(ids[x].first);
	}
	r.setSchema(newSchema);
	set<vector<string>>::iterator it;
	for(it = values.begin(); it != values.end(); ++it){
		vector<string> temp = *it;
		vector<string> tempVal;
		for(int x = 0; x < ids.size(); x++){
			for(int y = 0; y < schema.size(); y++){
				if(ids[x].first == schema[y]){
					tempVal.push_back(temp[y]);
					break;
				}
			}
		}
		r.addValue(tempVal);
	}
	return r;
}

//*********Renames the schema inside a relation with the given new name*****************************
relation relation::rename(vector<int> positions,string newName){
	relation r;
	r.setName(name);
	r.setSchema(schema);
	r.setValues(values);
	for(int x = 0; x < positions.size(); x++){
		r.setAttribute(positions[x],newName);
	}
	return r;
}

//**********Outputs the relation as a string to the console*****************************************
void relation::toString(){
	set<vector<string>>::iterator it;
	for(it = values.begin(); it != values.end(); ++it){
		vector<string> v = *it;
		if(schema.size() != 0)
			cout << "  ";
		for(int x = 0; x < schema.size(); x++){
			cout << schema[x] << "=" << v[x];
			if(x+1 != schema.size())
			cout << ", ";
		else
			cout << endl;
		}
	}
}

//**********Makes sure that the tuple can be selected on***************************************************
bool relation::isValidTuple(vector<pair<string,vector<int>>> ids, vector<string> tuple, int position){
	bool canSelect = true;
	for(int x = position+1; x < ids.size(); x++){
		if(ids[x].second.size() > 1){
			for(int y = 0; y < ids[x].second.size(); y++){
				if(y+1 != ids[x].second.size() && tuple[ids[x].second[y]] != tuple[ids[x].second[y+1]]){
					canSelect = false;
					break;
				}
			}	
		}
	}
	return canSelect;
}