#include "Token.h"
using namespace std;

//*********Sets the type of the token to the value of str********************************

void Token::setType(string str){
	type = str;
}

//*********Sets the value of the token to str*********************************************

void Token::setValue(string str){
	value = str;
}

//**********Sets the value of the line the token is on to i*******************************

void Token::setLine(int i){
	line = i;
}

//**********Returns the type of the token*************************************************

string Token::getType(){
	return type;
}

//**********Returns the value of the token************************************************

string Token::getValue(){
	return value;
}

//**********Returns the line the token is on**********************************************

int Token::getLine(){
	return line;
}

//**********Prints the token to the console in the format (TYPE,"VALUE",LINE)

void Token::printToken(){
	cout << "(" << type << ",\"" << value << "\"," << line << ")" << endl;
}