#pragma once

#include <string>
#include <vector>
#include "rule.h"

using namespace std;

class Tree{
public:
//*****Variables********************************************
	string root;				//root rule of the tree
	vector<Rule> components;	//SCC in the tree

//*****Constructor, get, and set functions******************
	//*****Constructor
	Tree();

	//*****Sets the root rule of the tree
	void setRoot(Rule);

	//*****Adds a componenet to the SCC
	void addSCC(Rule);

	//*****Returns the root rule
	string getRoot();

	//*****Returns the components in the SCC (ordered)
	vector<Rule> getSCC();

	//*****Resets the tree
	void clear();
};