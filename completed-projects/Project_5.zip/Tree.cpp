#include "Tree.h"

//*****Constructs a new tree with root r, which is added as a component
Tree::Tree(){}

//*****Sets the root rule of the tree***************************************
void Tree::setRoot(Rule r){
	root = r.getHeadPred().getName();
}

//*****Adds a component to the SCC******************************************
void Tree::addSCC(Rule r){
	components.push_back(r);
}

//*****Returns the root rule************************************************
string Tree::getRoot(){
	return root;
}

//*****Returns the components in the SCC (ordered)
vector<Rule> Tree::getSCC(){
	return components;
}

//*****Resets the tree******************************************************

void Tree::clear(){
	root.clear();
	components.clear();
}