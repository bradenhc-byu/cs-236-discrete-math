#include "Lexer.h"
using namespace std;

int main(int argc, char *argv[]){
	string filename = argv[1];
	Lexer l;
	l.scan(filename);
	l.printTokens();
	system("Pause");
	return 0;
}