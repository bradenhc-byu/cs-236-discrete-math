#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

#include "Token.h"
using namespace std;

class Lexer{
public:
	//variables
	char c;
	int line;
	int totaltokens;
	ifstream myfile;
	vector<Token> v;
	//get the input file and scan
	void scan(string);

	//get the output vector after the scan
	vector<Token> getVector();

	//check token functions
	string getId();
	void getString();
	void checkId(string);
	void checkCOLONorCOLON_DASH();
	void checkCOMMENTorBLOCK_COMMENT();
	bool isNewline(char);

	//create token and push to vector functions
	void pushCOMMA();
	void pushPERIOD();
	void pushQ_MARK();
	void pushLEFT_PAREN();
	void pushRIGHT_PAREN();
	void pushCOLON();
	void pushCOLON_DASH();
	void pushMULTIPLY();
	void pushADD();
	void pushSCHEMES();
	void pushFACTS();
	void pushRULES();
	void pushQUERIES();
	void pushID(string);
	void pushSTRING(string,int);
	void pushCOMMENT(string,int);
	void pushUNDEFINED(string,int);
	void pushEOF();

	//print function
	void printTokens();

};