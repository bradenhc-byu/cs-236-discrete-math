#include <string>
#include <iostream>
using namespace std;

//class to be put into vector of tokens
class Token{
public:
	//variables in Token class
	string type;
	string value;
	int line;

	//set variables
	void setType(string);
	void setValue(string);
	void setLine(int);

	//get variables
	string getType();
	string getValue();
	int getLine();

	//print token
	void printToken();
};