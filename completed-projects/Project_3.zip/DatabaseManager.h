#pragma once

#include "Parser.h"
#include "relation.h"
#include "predicate.h"
#include "database.h"
#include <string>
#include <iostream>
#include <vector>
#include <set>
#include <utility>

using namespace std;

class DatabaseManager{
public:
	//variables
	Database database;
	Predicate query;							//query to be analyzed
	vector<pair<string,vector<int>>> ids;		//ids in the query and their position

	
	//methods
	void manage(Database,vector<Predicate>,set<string>);
	relation getRelation(string,Predicate,set<string>);

	void addID(string,int);
	void getID(string,int);


};