#include "parameter.h"

void Parameter::setParam(string s){
	param = s;
}

string Parameter::getParam(){
	return param;
}

string Parameter::toString(){
	string out;
	out = param;
	return out;
}

