#include "DatabaseManager.h"

void DatabaseManager::manage(Database db, vector<Predicate> queries, set<string> domain){
	database = db;
	for(size_t qpos = 0; qpos < queries.size(); qpos++){
		ids.clear();								//reset the vector containing ids for this query
		query = queries[qpos];						//get the query
		cout << query.toString() << "? ";
		relation result = getRelation(query.getName(),query,domain);
		if(result.getValues().size() != 0){				//check to see if the query is true or false
			cout << "Yes(" << result.getValues().size() << ")" << endl;
			result.toString();
		}else{																//else ouptut no
			cout << "No" << endl;
		}
	}
}

relation DatabaseManager::getRelation(string name, Predicate q, set<string> domain){
	relation result;											//copy relation in database
	result.setName(query.getName());
	result.setSchema(database.getDatabase()[name].getSchema());
	result.setValues(database.getDatabase()[name].getValues());
	vector<Parameter> params = q.getParams();					//get parameters in query
	for(size_t x = 0; x < params.size(); x++){					//get all the ids or select on constants
		string value = params[x].getParam();
		if(domain.find(value) == domain.end()){				//if it is not a constant not in the domain
			if(value.at(0) == '\''){							//if it is a constant
				result.clear();										//return empty relation
				return result;
			}
			getID(value,x);
		}else												//if it is not an ID
			result = result.select(x,value);					//select on the constant
	}
	result = result.selectDuplicate(ids);
	for(int x = 0; x < ids.size(); x++)
		result = result.rename(ids[x].second,ids[x].first);
	result = result.project(ids);								//project on the relation with IDs
	return result;
}

void DatabaseManager::addID(string s, int i){
	pair<string,vector<int>> id;
	id.first = s;
	id.second.push_back(i);
	ids.push_back(id);
}

void DatabaseManager::getID(string value, int x){
	if(ids.size() == 0)									//if it is an ID
		addID(value,x);
	else{
		bool canAdd = true;
		for(int y = 0; y < ids.size(); y++){
			if(ids[y].first == value){					//if the ID is a duplicate
				ids[y].second.push_back(x);					//add its position
				canAdd = false;
			}			
		}
		if(canAdd)										//if the ID is unique
			addID(value,x);									//add new ID
	}
}