#pragma once

#include <string>
#include <set>
#include <vector>
#include <utility>
#include <iostream>

using namespace std;

class relation{
public:
	//variables
	string name;
	vector<string> schema;
	set<vector<string>> values;

	//get and set methods
	void setName(string);						//set the name of the realtion
	void setAttribute(int,string);				//sets the Attribute at a given location in schema
	void setSchema(vector<string>);				//sets the schema
	void setValues(set<vector<string>>);		//sets the values in the relation
	void addSchema(string);						//adds an attribute to the scema of this relation
	void addValue(vector<string>);				//adds a vector of values to this relation
	void clear();								//clears the relation
	string getName();							//gets the name of the relation
	vector<string> getSchema();					//gets the schema of the relation
	set<vector<string>> getValues();			//gets the set of vectors containing values of the relation

	//relational algebra
	relation select(int,string);				//selects on the relation	
	relation selectDuplicate(vector<pair<string,vector<int>>>);
	relation project(vector<pair<string,vector<int>>>);					//projects on the relation
	relation rename(vector<int>,string);			//renames attributes in the relation
	void eraseValue(set<vector<string>>::iterator);
	void toString();
	bool isValidTuple(vector<pair<string,vector<int>>>,vector<string>,int);

	
};