#pragma once

#include "Lexer.h"
#include "datalogProgram.h"
#include "predicate.h"
#include "rule.h"
#include "expressions.h"
#include "database.h"
#include "relation.h"
#include <string>
#include <vector>


using namespace std;

class Parser{
public:
	//variables
	int vpos;					//position in the vector
	int leftparen;				//counts number of left parentheses in expression
	int rightparen;				//counts number of right parentheses in expression
	datalogProgram p;			//start point for grammar
	Database d;
	vector<Parameter> param;	//vector of parameters for new predicate
	Predicate newPred;			//used to create new predicates
	Rule newRule;				//used to create new rules
	Expression newExp;			//used to create new expressions

	//get, set functions
	vector<Predicate> getQueries();
	set<string> getDomain();

	//functions
	Database parse(vector<Token>);			//will return "Success!" or "Failure!"
	void createexpression();			//creates a new expression to add as parameter
	void match(string type);			//checks to see if Tokens are in the Grammar

	//productions in Datalog grammar
	void scheme();
	void schemelist();
	void idlist();
	void factlist();
	void fact();
	void stringlist();
	void rulelist();
	void rule();
	void headpredicate();
	void predicate();
	void parameter();
	void expression();
	void operate();
	void paramlist();
	void predicatelist();
	void toquery();
	void toquerylist();

private:
	//variables
	vector<Token> vt;			//vector of tokens from Lexer
};