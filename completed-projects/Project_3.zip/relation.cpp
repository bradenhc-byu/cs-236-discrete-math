#include "relation.h"

void relation::setName(string s){					//sets the name
	name = s;
}

void relation::setAttribute(int x, string s){		//sets an attribute at a given location in the schema
	schema[x] = s;
}
void relation::addSchema(string s){					//adds an attribute to the schema
	schema.push_back(s);
}

void relation::addValue(vector<string> v){			//adds a vector of values to the relation
	values.insert(v);
}

void relation::clear(){								//clears the relation
	name = "";
	schema.clear();
	values.clear();
}

string relation::getName(){							//returns the name of the relation
	return name;
}

vector<string> relation::getSchema(){				//returns the vector containing the schema of the relation
	return schema;
}

set<vector<string>> relation::getValues(){			//returns a set containing vectors of the values in the relation
	return values;
}

void relation::setSchema(vector<string> s){			//sets the schema in a relation
	schema = s;
}

void relation::setValues(set<vector<string>> v){	//sets the values in a relation
	values = v;
}

relation relation::select(int x, string val){	//selects on the relation given an attribute location and value
	relation r;
	r.setName(name);
	r.setSchema(schema);
	set<vector<string>>::iterator it;
	for(it = values.begin();it != values.end(); ++it){
		vector<string> v = *it;
		if(v[x] == val){
			r.addValue(v);
		}
	}
	return r;
}

relation relation::selectDuplicate(vector<pair<string,vector<int>>> ids){
	relation r;
	r.setName(name);
	r.setSchema(schema);
	bool added = false;
	bool duplicate = false;
	vector<vector<string>> failedTuples;
	if(ids.size() == schema.size()){
		r.setValues(values);
		return r;
	}
	for(int x = 0; x < ids.size(); x++){
		if(ids[x].second.size() > 1){
			bool failed = false;
			duplicate = true;
			set<vector<string>>::iterator it;
			for(it = values.begin(); it != values.end(); it++){
				bool canSelect = true;
				vector<string> v = *it;
				for(int z = 0; z < failedTuples.size(); z++){
					if(failedTuples[z] == v)
						failed = true;
				}
				if(!failed){
					for(int y = 0; y < ids[x].second.size(); y++){
						if(y+1 != ids[x].second.size() && v[ids[x].second[y]] != v[ids[x].second[y+1]]){
							failedTuples.push_back(v);
							canSelect = false;
							break;
						}
					}
					if(canSelect && isValidTuple(ids,v,x)){
						r.addValue(v);
						added = true;
				}
				}
			}
		}
	}
	if(!added && !duplicate)
		r.setValues(values);
	return r;

}

relation relation::project(vector<pair<string,vector<int>>> ids){	//projects on a relation given the ids to be projected on
	relation r;
	r.setName(name);
	vector<string> newSchema;
	for(int x = 0; x < ids.size(); x++){
		newSchema.push_back(ids[x].first);
	}
	r.setSchema(newSchema);
	set<vector<string>>::iterator it;
	for(it = values.begin(); it != values.end(); ++it){
		vector<string> temp = *it;
		vector<string> tempVal;
		for(int x = 0; x < ids.size(); x++){
			tempVal.push_back(temp[ids[x].second[0]]);
		}
		r.addValue(tempVal);
	}
	return r;
}

relation relation::rename(vector<int> positions,string newName){	//changes the name of an attribute in the relation
	relation r;
	r.setName(name);
	r.setSchema(schema);
	r.setValues(values);
	for(int x = 0; x < positions.size(); x++){
		r.setAttribute(positions[x],newName);
	}
	return r;
	
	
}

void relation::toString(){
	set<vector<string>>::iterator it;
	for(it = values.begin(); it != values.end(); ++it){
		vector<string> v = *it;
		if(schema.size() != 0)
			cout << "  ";
		for(int x = 0; x < schema.size(); x++){
			cout << schema[x] << "=" << v[x];
			if(x+1 != schema.size())
			cout << ", ";
		else
			cout << endl;
		}
	}
}

bool relation::isValidTuple(vector<pair<string,vector<int>>> ids, vector<string> tuple, int position){
	bool canSelect = true;
	for(int x = position+1; x < ids.size(); x++){
		if(ids[x].second.size() > 1){
			for(int y = 0; y < ids[x].second.size(); y++){
				if(y+1 != ids[x].second.size() && tuple[ids[x].second[y]] != tuple[ids[x].second[y+1]]){
					canSelect = false;
					break;
				}
			}	
		}
	}
	return canSelect;
}