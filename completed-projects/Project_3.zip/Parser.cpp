#include "Parser.h"



Database Parser::parse(vector<Token> input){		//parse the tokens from the Lexer
	try{
		vt = input;				//get the vector
		vpos = 0;				//start at the beginning of vector
		leftparen = 0;			//initiate variables
		rightparen = 0;
		match("SCHEMES");		//begin parse
		match("COLON");
		scheme();				//replace with production scheme()
		schemelist();			//replace with production schemelist()
		match("FACTS");
		match("COLON");
		if(vt[vpos].getType() != "RULES")	//if there are facts, get
			factlist();				//replace with production factlist()
		match("RULES");
		match("COLON");
		if(vt[vpos].getType() != "QUERIES")	//if their are rules, get
			rulelist();				//replace with production rulelist()
		match("QUERIES");
		match("COLON");
		toquery();				//replace with production query()
		toquerylist();			//replace with production querylist()


		//p.toString();			//success, output program

	}
	catch(Token t){				//failure, output token
		cout << "Failure!" << endl << "  ";
		t.printToken();
		return d;
	}
	return d;
}

void Parser::match(string type){		//match and consume tokens in vector, or throw error
	if(type == vt[vpos].getType()){
		vpos++;
	}else{
		throw(vt[vpos]);
	}
}

void Parser::scheme(){						//scheme production
	newPred.setName(vt[vpos].getValue());	//create new predicate to add to scheme vector
	match("ID");
	match("LEFT_PAREN");
	newPred.addParam(vt[vpos].getValue());	//add parameter to predicate
	match("ID");
	if(vt[vpos].getType() == "COMMA"){
		idlist();
	}
	match("RIGHT_PAREN");
	p.addscheme(newPred);					//add scheme to scheme vector
	relation r;								//create and add new relation to database
	r.setName(newPred.getName());
	for(size_t x = 0; x < newPred.getParams().size(); x++){
		r.addSchema(newPred.getParams()[x].getParam());
	}
	d.addRelation(r);
	newPred.param.clear();					//reset parameter vector for next predicate
}

void Parser::idlist(){						//idlist production
	match("COMMA");
	newPred.addParam(vt[vpos].getValue());	//add parameter to predicate
	match("ID");
	if(vt[vpos].getType() == "COMMA")		//if more parameters, get (recursion)
		idlist();
}

void Parser::schemelist(){					//schemelist production
	while(vt[vpos].getType() != "FACTS")	//if more schemes, get (recursion)
		scheme();
}

void Parser:: factlist(){					//factlist production
	fact();
	while(vt[vpos].getType() != "RULES")	//if more facts, get (recursion)
		factlist();
}

void Parser::fact(){						//fact production
	newPred.setName(vt[vpos].getValue());	//create new predicate to add to facts vector
	match("ID");
	match("LEFT_PAREN");
	newPred.addParam(vt[vpos].getValue());	//add parameter to predicate for facts vector
	p.adddomain(vt[vpos].getValue());		//add parameter value to domain set
	match("STRING");
	if(vt[vpos].getType() == "COMMA")		//if more strings, get (recursion)
		stringlist();
	match("RIGHT_PAREN");
	match("PERIOD");
	p.addfact(newPred);						//add predicate to facts vector
	string rname = newPred.getName();
	if(d.has(rname)){
		d.addValue(rname,newPred.getStringParams());
	}
	newPred.param.clear();					//reset parameter vector for next predicate
}

void Parser::stringlist(){					//stringlist production
	match("COMMA");
	newPred.addParam(vt[vpos].getValue());	//add parameter to predicate
	p.adddomain(vt[vpos].getValue());		//add paramter value to domain set
	match("STRING");
	if(vt[vpos].getType() == "COMMA")		//if more strings, get (recursion)
		stringlist();
}

void Parser::rulelist(){					//rulelist production
	rule();									//get rule
	p.addrule(newRule);						//add rule to rule vector
	newRule.pred.clear();					//reset rule predicate vector for next rule
	while(vt[vpos].getType() != "QUERIES")	//if more rules, get (recursion)
		rulelist();
}

void Parser::rule(){					//rule production
	headpredicate();					//get head predicate
	match("COLON_DASH");
	predicate();						//get predicate
	newRule.addPred(newPred);			//add predicate to rule
	newPred.param.clear();				//reset predicate parameters for next predicate
	if(vt[vpos].getType() == "COMMA")	//if more predicates, get (recursion)
		predicatelist();
	match("PERIOD");
}

void Parser::headpredicate(){					//head predicate production
	newPred.setName(vt[vpos].getValue());		//create new predicate
	match("ID");
	match("LEFT_PAREN");
	newPred.addParam(vt[vpos].getValue());		//add parameter to predicate
	match("ID");
	if(vt[vpos].getType() == "COMMA")			//if more parameters, get (recursion)
		idlist();
	match("RIGHT_PAREN");
	newRule.setHeadPred(newPred);				//set head predicate for new rule
	newPred.param.clear();						//reset parameter vector for next predicate
}

void Parser::predicate(){					//predicate production
	newPred.setName(vt[vpos].getValue());	//create new predicate
	match("ID");
	match("LEFT_PAREN");
	parameter();							//get parameter
	if(vt[vpos].getType() == "COMMA")		//if more parameters, get (recurstion)
		paramlist();
	match("RIGHT_PAREN");
}

void Parser::parameter(){					//parameter production
	if(vt[vpos].getType() == "STRING"){		
		if(leftparen != rightparen)
			newExp.add(vt[vpos].getValue());		//if string and expression, add to expression
		else
			newPred.addParam(vt[vpos].getValue());	//else add parameter to predicate
		match("STRING");
	}else if(vt[vpos].getType() == "ID"){
		if(leftparen != rightparen)
			newExp.add(vt[vpos].getValue());		//if id and expression, add to expression
		else
			newPred.addParam(vt[vpos].getValue());	//else add parameter to predicate
		match("ID");
	}else{
		expression();								//create expression
		createexpression();
	}
}

void Parser::expression(){
	leftparen++;						//increment left_paren counter (used to determine when recursion should end)
	newExp.add(vt[vpos].getValue());	//add to expression
	match("LEFT_PAREN");
	parameter();						//get parameter, add to expression
	operate();							//add operator to expression
	parameter();						//get paramter, add to expression
	newExp.add(vt[vpos].getValue());	//add right parentheses to expression
	match("RIGHT_PAREN");
	rightparen++;						//increment right_paren counter
}

void Parser::operate(){						//determine what operator is and if it valid
	if(vt[vpos].getType() == "ADD"){
			newExp.add(vt[vpos].getValue());
			match("ADD");
		}
		else if(vt[vpos].getType() == "MULTIPLY"){
			newExp.add(vt[vpos].getValue());
			match("MULTIPLY");
		}else{
			throw(vt[vpos]);
	}
}

void Parser::paramlist(){				//parameter production
	match("COMMA");
	parameter();						//get parameter
	if(vt[vpos].getType() == "COMMA")	//if more parameters, get (recursion)
		paramlist();
}

void Parser::predicatelist(){			//predicate list production
	match("COMMA");
	predicate();						//get predicate
	newRule.addPred(newPred);			//add predicate to rule
	newPred.param.clear();				//reset predicate parameters for next predicate
	if(vt[vpos].getType() == "COMMA")	//if more predicate in rule, get (recursion)
		predicatelist();
}

void Parser::createexpression(){		//once expression has finished recursing, create new expression
	if(leftparen == rightparen){
		newPred.addParam(newExp.get());	//add parameter to predicate vector
		newExp.clear();					//reset expression variable
		leftparen = 0;					//reset left and right paren counters
		rightparen = 0;
	}
}

void Parser::toquery(){					//query production
	predicate();						// get predicate
	match("Q_MARK");
	p.addquery(newPred);				//add predicate to query vector
	newPred.param.clear();				//reset parameter vector for next predicate
}

void Parser::toquerylist(){				//querylist production
	while(vt[vpos].getType() != "EOF")	//if more queries, get (recursion)
		toquery();
}

vector<Predicate> Parser::getQueries(){
	return p.getQueries();
}

set<string> Parser::getDomain(){
	return p.getDomain();
}